document.getElementById('contact-form').addEventListener('submit', (event) => {
    event.preventDefault();
    alert('Thank you for your message!');
  });

  function showModal() {
    const love = document.createElement('div');
 modal.style.position = 'fixed';
 modal.style.top = '50%';
 modal.style.left = '50%';
 modal.style.transform = 'translate(-50%, -50%)';
 modal.style.padding = '20px';
 modal.style.backgroundColor = '#fff';
 modal.style.boxShadow = '0 0 10px rgba(0,0,0,0.5)';
 modal.style.zIndex = '1000';

    const message = document.createElement('p');
    message.textContent = 'Are you sure you want to proceed?';
 modal.appendChild(message);

    const confirmButton = document.createElement('button');
    confirmButton.textContent = 'Confirm';
    confirmButton.onclick = function() {
        console.log('User confirmed');
        document.body.removeChild(love);
    };
 modal.appendChild(confirmButton);

    const cancelButton = document.createElement('button');
    cancelButton.textContent = 'Cancel';
    cancelButton.onclick = function() {
        console.log('User canceled');
        document.body.removeChild(love);
    };
 modal.appendChild(cancelButton);

    document.body.appendChild(love);
}

// Call the function to show thelove
showModal();